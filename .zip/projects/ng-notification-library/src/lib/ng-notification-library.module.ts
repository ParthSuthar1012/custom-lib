import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NgNotificationLibraryComponent } from './ng-notification-library.component';



@NgModule({
  declarations: [
    NgNotificationLibraryComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [
    NgNotificationLibraryComponent
  ]
})
export class NgNotificationLibraryModule { }
