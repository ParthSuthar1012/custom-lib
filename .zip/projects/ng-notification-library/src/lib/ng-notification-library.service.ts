import { Injectable } from '@angular/core';
import { NgNotificationLibraryComponent } from './ng-notification-library.component'
@Injectable({
  providedIn: 'root'
})
export class NgNotificationLibraryService {

  constructor() { }

  notifications: NgNotificationLibraryComponent[] = [];

  addNotification(title: string, message: string, type: string) {
    const notification = new NgNotificationLibraryComponent();
    notification.title = title;
    notification.message = message;
    notification.type = type;
    this.notifications.push(notification);
  }

  removeNotification(notification: NgNotificationLibraryComponent) {
    const index = this.notifications.indexOf(notification);
    if (index >= 0) {
      this.notifications.splice(index, 1);
    }
  }
}
