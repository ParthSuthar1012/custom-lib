import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NgNotificationLibraryComponent } from './ng-notification-library.component';

describe('NgNotificationLibraryComponent', () => {
  let component: NgNotificationLibraryComponent;
  let fixture: ComponentFixture<NgNotificationLibraryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NgNotificationLibraryComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NgNotificationLibraryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
