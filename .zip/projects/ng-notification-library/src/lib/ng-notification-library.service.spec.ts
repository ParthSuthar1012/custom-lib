import { TestBed } from '@angular/core/testing';

import { NgNotificationLibraryService } from './ng-notification-library.service';

describe('NgNotificationLibraryService', () => {
  let service: NgNotificationLibraryService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(NgNotificationLibraryService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
