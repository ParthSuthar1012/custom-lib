import { Component, Input } from '@angular/core';

@Component({
  selector: 'lib-ng-notification-library',
  template: `
    <div [ngClass]="['notification', type]">
      <div class="title">{{ title }}</div>
      <div class="message">{{ message }}</div>
    </div>
  `,
  styles: [
  ]
})
export class NgNotificationLibraryComponent {
  @Input() title!: string;
  @Input() message!: string;
  @Input() type!: string;
}
